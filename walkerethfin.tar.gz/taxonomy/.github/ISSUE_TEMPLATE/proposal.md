---
name: Proposal
about: Create a contribution proposal
title: ''
labels: ''
assignees: ''

---

**Describe the proposed contribution to the taxonomy**

<!-- A concise description of what the proposed contribution would bring, replace "..." in the bullet list. -->

- ...
- ...
- ...

**Input given at the prompt**

<!-- What you entered, replace "..." -->

```
   ...
```

**Response from the current model**

<!-- What you received from the current model in response to your input, 
replace "..." -->

```
  ...
```

**Response that you would expect instead with the contribution**
<!-- What you expect to receive instead with the finetuned model, replace "...". -->

```
  ...
```
