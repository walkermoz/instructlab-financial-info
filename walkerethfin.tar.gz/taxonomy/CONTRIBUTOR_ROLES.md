# Contributor roles for InstructLab

For information about contributor roles, see [Contributor roles for InstructLab](https://github.com/instructlab/community/blob/main/CONTRIBUTOR_ROLES.md).